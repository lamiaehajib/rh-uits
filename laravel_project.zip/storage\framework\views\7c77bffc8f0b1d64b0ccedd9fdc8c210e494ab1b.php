<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
         body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #D32F2F;
            font-size: 2.5em;
            margin-bottom: 20px;
            text-align: center;
            border-bottom: 3px solid #C2185B;
            display: inline-block;
            padding-bottom: 10px;
        }

        .details-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
        }

        .details-container p {
            font-size: 1.1em;
            color: #555;
            margin: 10px 0;
        }

        .details-container p strong {
            color: #D32F2F;
        }

        .btn-secondary {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #C2185B;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease;
            text-align: center;
        }

        .btn-secondary:hover {
            background-color: #D32F2F;
        }
    </style>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("formation-show")): ?>
    <div class="details-container">
        <h2>Formation : <?php echo e($formation->name); ?></h2>
    
        <!-- Vérification d'accès -->
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
    
        <!-- Affichage des détails de la formation -->
        <div class="card mt-4">
            
            <div class="card-body">
                
                <p><strong>Status :</strong> <?php echo e($formation->status); ?></p>
                <p><strong>Formateur :</strong> <?php echo e($formation->nomformateur); ?></p>
                <p><strong>Date :</strong> <?php echo e($formation->date); ?></p>
                
                <!-- Affichage du fichier associé (si disponible) -->
                <?php if($formation->file_path): ?>
                    <p><strong>Fichier :</strong> <a href="<?php echo e(Storage::url($formation->file_path)); ?>" target="_blank">Télécharger le fichier</a></p>
                <?php else: ?>
                    <p>Aucun fichier associé.</p>
                <?php endif; ?>
    
                <!-- Affichage des utilisateurs associés -->
                <h5>Utilisateurs associés :</h5>
                <ul>
                    <?php $__currentLoopData = $formation->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($user->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
    
                <div class="mt-4">
                    <a href="<?php echo e(route('formations.index')); ?>" class="btn btn-secondary">Retour à la liste des formations</a>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/formations/show.blade.php ENDPATH**/ ?>