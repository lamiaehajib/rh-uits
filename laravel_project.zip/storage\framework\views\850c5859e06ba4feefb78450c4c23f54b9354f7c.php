<?php echo e($slot); ?>

<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>