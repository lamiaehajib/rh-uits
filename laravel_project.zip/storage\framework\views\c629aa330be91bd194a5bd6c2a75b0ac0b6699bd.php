<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
         body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            color: #333;
            padding: 20px;
        }

        h1 {
            color: #D32F2F;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .search-form {
            display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 25px;
    border: 2px solid #ddd;
    padding: 5px 15px;
    background-color: #f9f9f9;
    width: 500px;
    transition: all 0.3s ease;
    margin-left: 151px;
    }

    .search-form:hover {
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        border-color: #C2185B;
    }

    .form-control {
        width: 100%;
        padding: 10px;
        border: none;
        border-radius: 25px;
        outline: none;
        font-size: 16px;
        transition: border-color 0.3s;
    }

    .form-control:focus {
        border-color: #D32F2F;
    }
    .btn {
            background-color: #C2185B;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 0 20px 20px 0;
            cursor: pointer;
            transition: background-color 0.3s ease;
            justify-content: center !important;
    display: flex;
        }

    /* .btn {
        background-color: #D32F2F;
        color: white;
        border: none;
        padding: 10px 15px;
        border-radius: 50%;
        cursor: pointer;
        margin-left: 10px;
        transition: background-color 0.3s;
    } */

    /* .btn:hover {
        background-color: #C2185B;
    }

    .btn i {
        font-size: 18px;
    } */

    .btn-primary {
    margin-top: 35px; /* Ajoute un espace au-dessus du bouton */
    margin-bottom: 15px; /* Espace en dessous */
    background-color: #D32F2F;
    border: none;
    padding: 10px 20px;
    font-size: 1rem;
    color: white;
    border-radius: 5px;
    
}

        .btn-primary:hover {
            background-color: #C2185B;
        }

        .btn-info {
            background-color: #1976D2;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }

        .btn-warning {
            background-color: #FF9800;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }

        .btn-danger {
            background-color: #D32F2F;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }

        .btn-danger:hover {
            background-color: #C2185B;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #FFF;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.05);
            border-radius: 8px;
            overflow: hidden;
        }

        th {
            background-color: #C2185B;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: bold;
        }

        td {
            padding: 10px;
            text-align: left;
            border: 1px solid #EEE;
            color: #555;
        }

        tr:nth-child(even) {
            background-color: #FFEFF3; /* Rouge très pâle */
        }

        tr:hover {
            background-color: #FFCDD2; /* Rouge doux */
            transition: background-color 0.3s ease-in-out;
        }

        .alert-success {
            background-color: #388E3C;
            color: white;
            padding: 10px;
            border-radius: 5px;
        }

        .pagination {
            margin-top: 20px;
        }

        .pagination a {
            color: #D32F2F;
            text-decoration: none;
            padding: 8px 12px;
            border: 1px solid #D32F2F;
            border-radius: 5px;
        }

        .pagination a:hover {
            background-color: #D32F2F;
            color: white;
        }

        td.td-action {
    display: flex;
    gap: 10px;
    justify-content: center;
}

.btn-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 20vh; /* This ensures the button is centered vertically */
}
.btn-primary {
            background-color: #D32F2F;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            color: white;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: #C2185B;
        }
        .btn-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: auto; /* This ensures the button is centered vertically */
}
h2 {
            color: #D32F2F;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        


.btn:hover::after {
    content: attr(title);
    color: #fff;
    font-size: 14px;
    margin-left: 10px;
}
.form-control {
            width: 400px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 20px 0 0 20px;
            font-size: 16px;
            outline: none;
           
            
        }

        .form-control:focus {
            border-color: #D32F2F;
        }
        .input-group {
            display: flex;
            justify-content: center;
        }
       
        

    </style>

    <div class="row">
        <form method="GET" action="<?php echo e(route('users.index')); ?>">
            <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Rechercher..." value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn"><i class="fas fa-search"></i></button>
            </div>
        </form>
        <div class="col-lg-12 margin-tb">
           
            
            <div class="btn-container">
            
                <a  class="btn btn-primary" href="<?php echo e(route('users.create')); ?>">Create New User</a>
            </div>
        </div>
    </div>

    
    <div class="pull-left">
        <h2>équipe</h2>
    </div>
    <table class="table table-bordered">
        <tr>
            
            <th>Nom Complete</th>
            <th>Email</th>
            <th>Telephone</th>
            <th>Code</th>
            <th>Poste</th>
            <th>Adresse</th>
            <th>Repos</th>
            <th>Roles</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->tele); ?></td>
                <td><?php echo e($user->code); ?></td>
                <td><?php echo e($user->poste); ?></td>
                <td><?php echo e($user->adresse); ?></td>
                <td><?php echo e($user->repos); ?></td>
                <td>
                    <?php if(!empty($user->getRoleNames())): ?>
                        <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="badge badge-success"><?php echo e($v); ?></label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </td>
                <td class="td-action">
                    <a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>" title="Voir"><i class="fa fa-eye"></i></a>
                    <a class="btn btn-warning" href="<?php echo e(route('users.edit',$user->id)); ?>" title="Modifier"><i class="fa fa-edit"></i></a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['users.destroy', $user->id], 'style'=>'display:inline', 'id' => 'delete-form-'.$user->id ]); ?>

                    <button type="button" class="btn btn-danger"  onclick="confirmDelete(<?php echo e($user->id); ?>)" title="Supprimer"><i class="fa fa-trash"></i></button>
                <?php echo Form::close(); ?>


    
<?php endif; ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="d-flex justify-content-center my-4">
        <nav aria-label="Page navigation">
            <?php echo e($data->links('pagination.custom')); ?>

        </nav>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function () {
            <?php if(session('success')): ?>
                Swal.fire({
                    icon: 'success',
                    title: 'Succès',
                    text: '<?php echo e(session('success')); ?>',
                    confirmButtonText: 'OK',
                   
                });
            <?php elseif(session('error')): ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: '<?php echo e(session('error')); ?>',
                    confirmButtonText: 'OK',
                  
                });
            <?php endif; ?>
        });
    </script>

<script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Oui, supprimer !',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                // Soumettre le formulaire si l'utilisateur confirme
                document.getElementById('delete-form-' + id).submit();
            }
        });
    }
</script>
    
   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/users/index.blade.php ENDPATH**/ ?>