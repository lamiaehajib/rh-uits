<?php

// app/Http/Controllers/PointageController.php

// app/Http/Controllers/PointageController.php

namespace App\Http\Controllers;

use App\Models\SuivrePointage;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class SuivrePointageController extends Controller
{
    function __construct()                                 

    {
         $this->middleware('permission:pointage-list|pointage-create|pointage-edit|pointage-delete', ['only' => ['index','show']]);

         $this->middleware('permission:pointage-show', ['only' => ['pointer']]);

         
    }
    public function index()
    {
        $user = auth()->user();
        
        $query = SuivrePointage::with('user');
    
        // If search is provided, filter by user name or date
        if ($search = request('search')) {
            $query->whereHas('user', function ($query) use ($search) {
                $query->where('name', 'like', "%{$search}%"); // Filter by user's name
            })
            ->orWhereDate('created_at', 'like', "%{$search}%"); // Filter by the date (if search matches the date)
        }
    
        // Handle the pagination
        if ($user->hasRole('Admin') || $user->hasRole('admis3(addellatif)')) {
            $pointages = $query->paginate(5);
        } else {
            $pointages = $query->where('iduser', $user->id)->paginate(10);
        }
    
        return view('suivre_pointage.index', compact('pointages'));
    }

    public function pointer(Request $request)
{
    // Get the location from the request (you will pass this from the frontend)
    $location = $request->input('localisation'); 
    
    $pointage = SuivrePointage::where('iduser', Auth::id())->latest()->first();

    if (!$pointage || ($pointage && $pointage->heure_depart && $pointage->heure_arrivee)) {
        // Start a new pointage if none exists or both times are filled
        $pointage = SuivrePointage::create([
            'iduser' => Auth::id(),
            'heure_depart' => Carbon::now(),
            'localisation' => $location,  // Enregistre la localisation
        ]);
        
    } elseif ($pointage->heure_depart && !$pointage->heure_arrivee) {
        // Set heure_arrivee, description, and location
        $pointage->update([
            'heure_arrivee' => Carbon::now(),
            'description' => $request->input('description'),
            'localisation' => $location, // Save the location
        ]);
    }

    return redirect()->route('suivre_pointage.index');
}
}
