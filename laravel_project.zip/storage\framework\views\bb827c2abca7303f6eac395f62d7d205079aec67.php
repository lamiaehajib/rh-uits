<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', "Oups ! La page que vous cherchez semble introuvable. Pas de panique, cliquez ci-dessous pour revenir à l'accueil."); ?>


<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/errors/404.blade.php ENDPATH**/ ?>