<tr>
    <td>
    <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
    <tr>
    <td class="content-cell" align="center">
    <p style="font-size: 14px; color: #555;">
        &copy; 2024 .uits.Tous droits réservés. <br>
        
    </p>
    </td>
    </tr>
    </table>
    
    </td>
    </tr>
    <?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>