<?php echo e($slot); ?>

<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>