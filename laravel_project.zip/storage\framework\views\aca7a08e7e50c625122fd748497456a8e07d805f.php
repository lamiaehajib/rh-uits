
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* Style de la modale */
        .modal {
            display: none; /* Caché par défaut */
            position: fixed; 
            z-index: 1000; 
            padding-top: 60px; 
            left: 0;
            top: 0;
            width: 100%; 
            height: 100%; 
            overflow: auto; 
            background-color: rgba(0, 0, 0, 0.8); /* Fond sombre avec opacité */
        }
        
        /* Image à l'intérieur de la modale */
        .modal-content {
            margin: auto;
            display: block;
            max-width: 80%; /* Largeur maximale */
            max-height: 80%; /* Hauteur maximale */
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            transition: transform 0.3s ease; /* Animation fluide */
        }
        
        /* Effet de zoom */
        .modal-content:hover {
            transform: scale(1.05); /* Zoom au survol */
        }
        
        /* Bouton de fermeture */
        .close {
            position: absolute;
            top: 15px;
            right: 35px;
            color: white;
            font-size: 30px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }
        
        .close:hover,
        .close:focus {
            color: #f00; /* Rouge au survol */
            text-decoration: none;
        }
        .modal-content {
    transform: scale(0.8);
    animation: zoomIn 0.4s ease;
}

@keyframes zoomIn {
    from {
        transform: scale(0.8);
        opacity: 0;
    }
    to {
        transform: scale(1);
        opacity: 1;
    }
}
body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    margin: 0;
    padding: 0;
}

/* .container {
    max-width: 100% !important;
    margin: 50px auto;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 20px;
} */

h1 {
    color: #D32F2F;
    text-align: center;
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: bold;
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    color: #fff;
    font-size: 14px;
    cursor: pointer;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.btn-primary {
    background-color: #C2185B;
}

.btn-primary:hover {
    background-color: #D32F2F;
}

.btn-warning {
    background-color: #FFC107;
    color: #000;
}

.btn-info {
    background-color: #17A2B8;
}

.btn-danger {
    background-color: #D32F2F;
}

.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.table thead th {
    background-color: #D32F2F;
    color: #fff;
    text-align: left;
    padding: 10px;
}

.table tbody tr {
    border-bottom: 1px solid #ddd;
}

.table tbody td {
    padding: 10px;
    text-align: left;
}

.table tbody tr:hover {
    background-color: #f1f1f1;
}
body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            color: #333;
            padding: 20px;
        }

        h2 {
            color: #D32F2F;
            font-size: 1.8rem;
            margin-bottom: 20px;
        }

        .search-form {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
           
        }

        .form-control {
            width: 400px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 20px 0 0 20px;
            font-size: 16px;
            outline: none;
           
            
        }

        .form-control:focus {
            border-color: #D32F2F;
        }

        .btn {
            background-color: #C2185B;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 0 20px 20px 0;
            cursor: pointer;
            transition: background-color 0.3s ease;
            justify-content: center !important;
    display: flex;
        }

        .btn:hover {
            background-color: #D32F2F;
        }

        .btn-primary {
    margin-top: 35px; /* Ajoute un espace au-dessus du bouton */
    margin-bottom: 15px; /* Espace en dessous */
    background-color: #D32F2F;
    border: none;
    padding: 10px 20px;
    font-size: 1rem;
    color: white;
    border-radius: 5px;
    
}
.button-container {
    
    display: flex;
    justify-content: center; /* Ajuste cette valeur pour descendre le bouton */
}



        .btn-primary:hover {
            background-color: #C2185B;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            background-color: #FFF;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.05);
            border-radius: 8px;
            overflow: hidden;
        }

        th {
            background-color: #C2185B;
            color: white;
            padding: 12px;
            text-align: left;
        }

        td {
            padding: 10px;
            border: 1px solid #EEE;
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: #FFEFF3;
        }

        tr:hover {
            background-color: #FFCDD2;
            transition: background-color 0.3s ease-in-out;
        }

        .alert-success {
            background-color: #388E3C;
            color: white;
            padding: 10px;
            border-radius: 5px;
        }

        .pagination {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }

        .pagination a {
            color: #D32F2F;
            text-decoration: none;
            padding: 8px 12px;
            border: 1px solid #D32F2F;
            border-radius: 5px;
        }

        .pagination a:hover {
            background-color: #D32F2F;
            color: white;
        }

        .btn-info {
            background-color: #1976D2;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }

        .btn-warning {
            background-color: #FF9800;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }

        .btn-danger {
            background-color: #D32F2F;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }

        .btn-danger:hover {
            background-color: #C2185B;
        }

        td.td-action {
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        .input-group {
            display: flex;
            justify-content: center;
        }

        .btn-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 20vh; /* This ensures the button is centered vertically */
}

        </style>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("image_preuve-list")): ?>
    <div class="container">
        <form method="GET" action="<?php echo e(route('image_preuve.index')); ?>">
            <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Rechercher..." value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn"><i class="fas fa-search"></i></button>
            </div>
        </form>
        
        
         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("image_preuve-create")): ?>
         <a href="<?php echo e(route('image_preuve.create')); ?>" class="btn btn-primary">Ajouter une nouvelle image preuve</a>
         <?php endif; ?>
        
        <h2 class="mb-4">Liste des Images Preuves</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Date</th>
                    <th>Nom de l'utilisateur</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $imagePreuves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagePreuve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($imagePreuve->titre); ?></td>
                        <td><?php echo e($imagePreuve->description); ?></td>
                        <td>
                            <img 
                                src="<?php echo e(Storage::url($imagePreuve->image)); ?>" 
                                alt="<?php echo e($imagePreuve->titre); ?>" 
                                style="width: 100px; height: auto; cursor: pointer;" 
                                onclick="openModal('<?php echo e(Storage::url($imagePreuve->image)); ?>')"
                            >
                        </td>
                        
                        <!-- La modale pour afficher l'image en grand -->
                        <div id="imageModal" class="modal" onclick="closeModal()">
                            <span class="close">&times;</span>
                            <img class="modal-content" id="modalImage">
                        </div>
                        
                        <td><?php echo e($imagePreuve->date); ?></td>
                        <td><?php echo e($imagePreuve->user->name); ?></td>
                        <td class="td-action">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("image_preuve-edit")): ?>
                            <a href="<?php echo e(route('image_preuve.edit', $imagePreuve->id)); ?>" class="btn btn-warning"title="Modifier"><i class="fa fa-edit"></i></a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("image_preuve-show")): ?>
                            <a href="<?php echo e(route('image_preuve.download', $imagePreuve->id)); ?>" class="btn btn-info"title="Télécharger"><i class="fa fa-download"></i></a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("image_preuve-delete")): ?>
                            <form action="<?php echo e(route('image_preuve.destroy', $imagePreuve->id)); ?>" method="POST" style="display:inline-block;" id="delete-form-<?php echo e($imagePreuve->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="button" class="btn btn-danger" onclick="confirmDelete(<?php echo e($imagePreuve->id); ?>)" title="Supprimer">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                            
                            
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
    </div>
    <div class="d-flex justify-content-center my-4">
        <nav aria-label="Page navigation">
            <?php echo e($imagePreuves->links('pagination.custom')); ?>

        </nav>
    </div>
    <script>
        function openModal(imageUrl) {
            // Afficher la modale et définir l'image
            const modal = document.getElementById('imageModal');
            const modalImage = document.getElementById('modalImage');
            modal.style.display = 'block';
            modalImage.src = imageUrl;
        }
    
        function closeModal() {
            // Cacher la modale
            const modal = document.getElementById('imageModal');
            modal.style.display = 'none';
        }
    </script>
     <script>
        document.addEventListener('DOMContentLoaded', function () {
            <?php if(session('success')): ?>
                Swal.fire({
                    icon: 'success',
                    title: 'Succès',
                    text: '<?php echo e(session('success')); ?>',
                    confirmButtonText: 'OK',
                   
                });
            <?php elseif(session('error')): ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: '<?php echo e(session('error')); ?>',
                    confirmButtonText: 'OK',
                  
                });
            <?php endif; ?>
        });
    </script>
    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Êtes-vous sûr ?',
                text: "Cette action est irréversible.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Oui, supprimer !',
                cancelButtonText: 'Annuler'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Soumettre le formulaire si l'utilisateur confirme
                    document.getElementById('delete-form-' + id).submit();
                }
            });
        }
    </script>
    
    <?php endif; ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/image_preuve/index.blade.php ENDPATH**/ ?>