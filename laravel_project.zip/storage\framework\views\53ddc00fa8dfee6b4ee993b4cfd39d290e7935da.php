<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* Container and Header Styles */
.container {
    max-width: 700px;
    margin: 40px auto;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    font-family: 'Arial', sans-serif;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.header h2 {
    font-size: 28px;
    color: #333;
    margin: 0;
}

.btn {
    text-decoration: none;
    padding: 10px 15px;
    border-radius: 5px;
    font-size: 14px;
    font-weight: bold;
    display: inline-flex;
    align-items: center;
    background-color: #007bff;
    color: white;
    transition: background-color 0.3s ease;
}

.btn:hover {
    background-color: #0056b3;
}

/* Details Section */
.details {
    padding: 20px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
}

.field {
    margin-bottom: 20px;
}

.field strong {
    display: block;
    font-size: 16px;
    color: #555;
    margin-bottom: 5px;
}

.value {
    font-size: 18px;
    font-weight: bold;
    color: #333;
}

/* Permissions Badges */
.permissions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.badge {
    display: inline-block;
    padding: 5px 10px;
    font-size: 14px;
    color: white;
    background-color: #eb3333;
    border-radius: 12px;
}

.badge:hover {
    background-color: #a52f31;
}

/* No Permissions */
.no-permissions {
    font-size: 14px;
    color: #888;
    font-style: italic;
}

    </style>
    <div class="container">
        <div class="header">
            <h2>Show Role</h2>
            <a class="btn btn-primary" href="<?php echo e(route('roles.index')); ?>">🔙 Back</a>
        </div>

        <div class="details">
            <div class="field">
                <strong>Name:</strong>
                <span class="value"><?php echo e($role->name); ?></span>
            </div>

            <div class="field">
                <strong>Permissions:</strong>
                <div class="permissions">
                    <?php if(!empty($rolePermissions)): ?>
                        <?php $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge"><?php echo e($v->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <span class="no-permissions">No permissions assigned</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/roles/show.blade.php ENDPATH**/ ?>