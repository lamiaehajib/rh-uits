<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
            body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .form-card {
            background: #cedce7;
    background: -webkit-linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
    background: -o-linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
    background: linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
    background: linear-gradient(178deg, #ff8080, #fdfcfc, #ff0e0e, #d53070);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
        }

        h1 {
            font-size: 2rem;
            font-weight: 600;
            color: #C2185B;
            margin-bottom: 20px;
            text-align: center;
        }

        label {
            font-size: 1rem;
            font-weight: 500;
            color: #444;
        }

        .form-control {
            background-color: #fafafa;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            font-size: 1rem;
            width: 100%;
            margin-bottom: 20px;
        }

        .form-control:focus {
            border-color: #D32F2F;
            box-shadow: 0 0 5px rgba(211, 47, 47, 0.5);
        }

        .btn-primary {
            background-color: #D32F2F;
            border: none;
            color: #fff;
            padding: 12px 20px;
            font-size: 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #C2185B;
        }

        .alert-danger {
            background-color: #F8D7DA;
            color: #721C24;
            border: 1px solid #F5C6CB;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .alert-danger ul {
            list-style-type: none;
            padding: 0;
        }

        .alert-danger li {
            margin-bottom: 5px;
        }
        .div-flex {
  display: flex;
  gap: 45px;
        }
        #clas-da{
            margin-top: 20px;
        }
    </style>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("tache-edit")): ?>
    <div class="container">
        <h1>Modifier la Tâche</h1>
        <div class="form-card">
        <form action="<?php echo e(route('taches.update', $tache->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
    
            <div class="div-flex">
            <div class="form-group">
                <label>date debut</label>
                <input type="date" name="datedebut" class="form-control" value="<?php echo e($tache->datedebut); ?>" required>
            </div>
    
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control" required>
                    <option value="nouveau" <?php echo e($tache->status == 'nouveau' ? 'selected' : ''); ?>>Nouveau</option>
                    <option value="en cours" <?php echo e($tache->status == 'en cours' ? 'selected' : ''); ?>>En cours</option>
                    <option value="termine" <?php echo e($tache->status == 'termine' ? 'selected' : ''); ?>>Terminé</option>
                </select>
            </div>
    
           
    
            

            <div class="form-group">
                <label for="iduser">Utilisateur</label>
                <select name="iduser" id="iduser" class="form-control" required>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tache->iduser); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            </div>
  
            <div class="div-flex">
            <div class="form-group">
                <label>Durée</label>
                <input type="text" name="duree" class="form-control" value="<?php echo e($tache->duree); ?>" required>
            </div>

            <div class="form-group" id="clas-da">
                
                <select name="date" class="form-control" required>
                    <option value="jour" <?php echo e($tache->date == 'jour' ? 'selected' : ''); ?>>Jour</option>
                    <option value="semaine" <?php echo e($tache->date == 'semaine' ? 'selected' : ''); ?>>Semaine</option>
                    <option value="mois" <?php echo e($tache->date == 'mois' ? 'selected' : ''); ?>>Mois</option>
                </select>
            </div>

            </div>

            <div class="form-group">
                <label>Description</label>
                <textarea name="description" class="form-control" required><?php echo e($tache->description); ?></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary mt-3">Mettre à jour</button>
        </form>
        </div>
    </div>
  
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/taches/edit.blade.php ENDPATH**/ ?>