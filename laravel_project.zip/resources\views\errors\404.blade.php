@extends('errors::minimal')

@section('title', __('Not Found'))
@section('code', '404')
@section('message', "Oups ! La page que vous cherchez semble introuvable. Pas de panique, cliquez ci-dessous pour revenir à l'accueil.")

