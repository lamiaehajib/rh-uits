<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* Couleurs de fond et du texte */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .form-card {
            background: #cedce7;
    background: -webkit-linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
    background: -o-linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
    background: linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
    background: linear-gradient(178deg, #ff8080, #fdfcfc, #ff0e0e, #d53070);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
        }

        h1 {
            font-size: 2rem;
            font-weight: 600;
            color: #C2185B;
            margin-bottom: 20px;
            text-align: center;
        }

        label {
            font-size: 1rem;
            font-weight: 500;
            color: #444;
        }

        .form-control {
            background-color: #fafafa;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            font-size: 1rem;
            width: 100%;
            margin-bottom: 20px;
        }

        .form-control:focus {
            border-color: #D32F2F;
            box-shadow: 0 0 5px rgba(211, 47, 47, 0.5);
        }

        .btn-primary {
            background-color: #D32F2F;
            border: none;
            color: #fff;
            padding: 12px 20px;
            font-size: 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #C2185B;
        }

        .alert-danger {
            background-color: #F8D7DA;
            color: #721C24;
            border: 1px solid #F5C6CB;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .alert-danger ul {
            list-style-type: none;
            padding: 0;
        }

        .alert-danger li {
            margin-bottom: 5px;
        }
        .div-flex {
  display: flex;
  gap: 45px;
 
}
    </style>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("formation-edit")): ?>
    <div class="container">
        <h1>Modifier la formation : <?php echo e($formation->name); ?></h1>
    
        <!-- Affichage des messages de succès ou d'erreur -->
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="form-card">
        <form action="<?php echo e(route('formations.update', $formation->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="div-flex">
            <div class="form-group">
                <label for="name">Nom de la formation</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $formation->name)); ?>" required>
            </div>
    
            <div class="form-group">
                <label for="status">Statut</label>
                <select class="form-control" id="status" name="status" required>
                    <option value="en ligne" <?php echo e(old('status', $formation->status) == 'en ligne' ? 'selected' : ''); ?>>En ligne</option>
                    <option value="lieu" <?php echo e(old('status', $formation->status) == 'lieu' ? 'selected' : ''); ?>>Lieu</option>
                </select>
            </div>
    
            <div class="form-group">
                <label for="nomformateur">Nom du formateur</label>
                <input type="text" class="form-control" id="nomformateur" name="nomformateur" value="<?php echo e(old('nomformateur', $formation->nomformateur)); ?>" required>
            </div>
            </div>
            <div class="div-flex">
            <div class="form-group">
                <label for="iduser">Utilisateurs associés</label>
                <select name="iduser[]" class="form-control select2" multiple required> 
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" 
                            <?php echo e(in_array($user->id, $formation->users->pluck('id')->toArray()) ? 'selected' : ''); ?>>
                            <?php echo e($user->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                

                
            </div>
    
            <div class="form-group">
                <label for="date">Date de la formation</label>
                <input type="date" class="form-control" id="date" name="date" value="<?php echo e(old('date', $formation->date)); ?>" required>
            </div>
            </div>
            <div class="div-flex">
            <div class="form-group">
                <label for="file">Fichier d'emploi du temps (PDF, DOC, DOCX)</label>
                <input type="file" class="form-control" id="file" name="file">
                <?php if($formation->file_path): ?>
                    <p>Fichier actuel : <a href="<?php echo e(asset('storage/' . $formation->file_path)); ?>" target="_blank">Voir le fichier</a></p>
                <?php endif; ?>
            </div>
            </div>
    
            <button type="submit" class="btn btn-primary">Mettre à jour la formation</button>
        </form>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                placeholder: "Sélectionnez des utilisateurs",
                allowClear: true
            });
        });
    </script>
     <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/formations/edit.blade.php ENDPATH**/ ?>