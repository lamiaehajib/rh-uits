@extends('errors::minimal')

@section('title', __('Forbidden'))
@section('code', '403')
@section('message','Oups ! Vous n`avez pas les permissions nécessaires pour accéder à cette page')
