<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            text-align: center;
            padding: 50px;
        }
        h1 {
            font-size: 80px;
            color: #e74c3c;
        }
        p {
            font-size: 24px;
        }
        
    </style>
</head>
<body>
    <h1><?php echo $__env->yieldContent('code'); ?></h1>
    <p><?php echo $__env->yieldContent('message'); ?></p>
    <a href="<?php echo e(url('/dashboard')); ?>" style="text-decoration: none; color: #ff0000;">Retourner à l'accueil</a>
</body>
</html>
<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/errors/minimal.blade.php ENDPATH**/ ?>