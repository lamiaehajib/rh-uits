<?php if(isset($slot)): ?>
<p style="font-size: 12px; color: #555;">
    Si vous rencontrez des difficultés pour cliquer sur le bouton "Voir".
</p>

<?php endif; ?>
<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/vendor/mail/html/subcopy.blade.php ENDPATH**/ ?>