<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
            color: #333;
        }

        h3 {
            font-size: 24px;
            color: #333;
            margin: 20px 0;
            text-align: center;
        }

        table {
            
            width: 100%;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px 20px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #d82e34;
            color: white;
            font-weight: bold;
        }

        td {
            background-color: #fff;
        }

        td span {
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
            cursor: pointer;
        }

        .green {
            color: green;
        }

        .red {
            color: red;
        }
        h3 {
    font-size: 28px;
    color: #f04242;
    font-weight: bold;
    text-align: center;
   
    letter-spacing: 2px;
    margin-bottom: 20px;
}


form {
    
            background-color: #ffffff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 200px;
            max-height: 212px;
            margin-top: 21px;
        }

        form div {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"], input[type="date"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus, input[type="date"]:focus {
            border-color: #5d9cec;
            outline: none;
        }

        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #f43c3c;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #aa3b46;
        }
        .div-flex{
            display: flex;
            gap: 30px;
        }

    </style>

    <h3>Historique des connexions</h3>
    <div class="div-flex">
    <form method="GET" action="<?php echo e(route('login.history')); ?>">
        <div>
            <label for="username">Nom d'utilisateur :</label>
            <input type="text" name="username" id="username" value="<?php echo e(request('username')); ?>">
        </div>
        <div>
            <label for="date">Date :</label>
            <input type="date" name="date" id="date" value="<?php echo e(request('date')); ?>">
        </div>
        <button type="submit">Rechercher</button>
    </form>
    <table>
        <thead>
            <tr>
                <th>Jour</th>
                <th>Utilisateur</th>
                <th>Heure de Connexion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $dayOfWeek = \Carbon\Carbon::parse($log->logged_in_at)->locale('fr')->dayName;
                ?>
                <tr>
                    <td><?php echo e(ucfirst($dayOfWeek)); ?> (<?php echo e(\Carbon\Carbon::parse($log->logged_in_at)->format('d/m/Y')); ?>)</td>
                    <td><?php echo e($log->user->name); ?></td>
                    <td>
                        <span class="green">Connecté à <?php echo e(\Carbon\Carbon::parse($log->logged_in_at)->timezone('Africa/Casablanca')->format('H:i')); ?></span>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
            <?php if($logs->isEmpty()): ?>
                <tr>
                    <td colspan="3">Aucun résultat trouvé</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
    <div class="d-flex justify-content-center my-4">
        <nav aria-label="Page navigation">
            <?php echo e($logs->links('pagination.custom')); ?>

        </nav>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/auth/login_history.blade.php ENDPATH**/ ?>