<?php $__env->startSection('title', __('Forbidden')); ?>
<?php $__env->startSection('code', '403'); ?>
<?php $__env->startSection('message','Oups ! Vous n`avez pas les permissions nécessaires pour accéder à cette page'); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/errors/403.blade.php ENDPATH**/ ?>