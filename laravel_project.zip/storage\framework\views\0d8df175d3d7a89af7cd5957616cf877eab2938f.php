
    <style>
        .pagination {
            display: flex;
            padding-left: 0;
            list-style: none;
            border-radius: 0.375rem;
            justify-content: center;
        }
        
        .pagination .page-item .page-link {
            color: #6c757d;
            border: 1px solid #dee2e6;
            margin: 0 0.2rem;
            padding: 0.5rem 0.75rem;
            cursor: pointer;
            transition: all 0.3s ease, transform 0.2s ease;
        }
        
        .pagination .page-item.active .page-link {
            background-color: #D32F2F;
            border-color: #C2185B;
            color: #fff;
            box-shadow: 0 4px 10px rgba(194, 69, 69, 0.3);
        }
        
        .pagination .page-item .page-link:hover {
            background-color: #be3030;
            border-color: #dee2e6;
            transform: translateY(-2px);
        }
        
        .pagination .page-item.disabled .page-link {
            color: #adb5bd;
            cursor: not-allowed;
        }
        
        .pagination .page-item .page-link:focus {
            outline: none;
            box-shadow: 0 0 8px rgba(162, 55, 55, 0.5);
        }
        </style>
        
        <?php if($paginator->hasPages()): ?>
        <ul class="pagination justify-content-center">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">&laquo;</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&laquo;</a></li>
            <?php endif; ?>
    
            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                <?php if(is_string($element)): ?>
                    <li class="page-item disabled"><span class="page-link"><?php echo e($element); ?></span></li>
                <?php endif; ?>
    
                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">&raquo;</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">&raquo;</span></li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const links = document.querySelectorAll('.page-link');
        
            links.forEach(link => {
                link.addEventListener('click', (e) => {
                    const parentItem = e.target.closest('.page-item');
                    if (parentItem && !parentItem.classList.contains('disabled')) {
                        parentItem.classList.add('clicked');
                        setTimeout(() => parentItem.classList.remove('clicked'), 300);
                    }
                });
            });
        });
        </script>
            

<?php /**PATH C:\Users\4B TECHNOLOGY\OneDrive\Bureau\tachehiv\resources\views/pagination/custom.blade.php ENDPATH**/ ?>